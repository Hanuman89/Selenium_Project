package testngClasses;
import org.junit.Assert;
import org.openqa.selenium. WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 
import org.openqa.selenium.support. PageFactory; 
import org.testng.annotations.AfterClass; 
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObjectModel.PageObjectModel_signup;

public class CertificationProject 
{

WebDriver driver = null; 

PageObjectModel_signup pobj = null;

@BeforeClass
public void beforeClass() 
{
driver = new ChromeDriver();
pobj = PageFactory.initElements(driver, PageObjectModel_signup.class);
}

@AfterClass
public void afterClass() 
{
  driver.quit();
}


@Test (priority = 1)

public void application_url_is_enabled() {

	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\OneDrive\\Desktop\\Java\\chromedriver.exe");
    System.out.println("Browser is opened.");

}
@Test (priority = 2)
public void open_application_home_page_through_url() {
driver.navigate().to("https://demoblaze.com/"); 
driver.manage() .window().maximize();
System.out.println("Application URL is entered.");
}
@Test (priority = 3)

public void application_home_page_is_displayed() {
if (!pobj.homepagelogo_img.isDisplayed()) {
System.out.println("Application home page is not visible."); 
System.out.println("test case failed!"); Assert.assertTrue(false);
} else
{
System.out.println("Application home page is visible.");
}
}
}
