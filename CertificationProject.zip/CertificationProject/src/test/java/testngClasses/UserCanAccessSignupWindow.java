package testngClasses;
import pageObjectModel.PageObjectModel_signup;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory; 
import org.testng.annotations.AfterClass; 
import org.testng.annotations.BeforeClass; 
import org.testng.annotations.Test;

public class UserCanAccessSignupWindow 
{ 
	WebDriver driver= null;
	PageObjectModel_signup pobj = null;

@BeforeClass

public void beforeClass() 
{
driver = new ChromeDriver();
pobj = PageFactory.initElements(driver, PageObjectModel_signup.class);
}

@AfterClass
public void afterClass () 
{
driver.close();
}

@Test (priority = 1)

public void user_is_on_application_home_page() 
{
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\OneDrive\\Desktop\\Java\\chromedriver.exe"); 
driver.navigate().to("https://demoblaze.com/"); 
driver.manage (). window().maximize();

if (!driver.getTitle().equals ("STORE")) {
System.out.println("User is not on application home page"); Assert.assertTrue (false);
} else {
}
System.out.println("User is on application home page");
}

@Test (priority = 2)
public void click_on_signup_link() {
pobj.signup_link.click();

try 
{
Thread.sleep(3000);
} catch (InterruptedException e) {
}

System.out.println("Signup link is clicked.");

}
@Test (priority= 3)

public void signup_window_is_displayed () {
if (!pobj.signup_window.isDisplayed()) {
System.out.println("Signup window is not visible."); 

System.out.println("test case failed!");
Assert.assertTrue (false);
} else {
System.out.println("Signup window is visible.");
}
}

@Test (priority = 4)

public void all_elements_in_the_signup_window_are_visible() {
if (!pobj.user_input.isEnabled()) {
System.out.println("Username field is not visible."); Assert.assertTrue(false);
} else 
{
System.out.println("Username field is visible.");
}
if (!pobj.password_input.isEnabled()) 
{
System.out.println("Password field is not visible."); Assert.assertTrue(false);
} else {
System.out.println("Password field is visible.");
}
if (!pobj.signup_button.isEnabled()) 
{
System.out.println("Signup button is not visible.");
} else 
{
	System.out.println("Signup button is visible.");
}
if (!pobj.signupClose_button.isEnabled()) 
{
System.out.println("Signup window close button is not visible."); Assert.assertTrue(false);
} else {
System.out.println("Signup window close button is visible.");
}
}
}
