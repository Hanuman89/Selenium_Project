package testngClasses;
import pageObjectModel.PageObjectModel_signup;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.support.PageFactory; 
import org.testng.annotations.AfterClass; 
import org.testng.annotations.BeforeClass; 
import org.testng.annotations.Test;

public class UserIsNotAbleToRegisterIfTheGivenUsernameAlreadyExist 
{
WebDriver driver = null;
PageObjectModel_signup pobj = null;

@BeforeClass

public void beforeClass() 
{
driver = new ChromeDriver();
pobj = PageFactory.initElements(driver, PageObjectModel_signup.class);
}

@AfterClass
public void afterClass() 
{
driver.close();
}

@Test (priority = 1)

public void user_is_on_application_home_page() 
{
System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\OneDrive\\Desktop\\Java\\chromedriver.exe");
driver.navigate().to("https://demoblaze.com/");
driver.manage().window().maximize();
if (!driver.getTitle().equals("STORE")) 
{
System.out.println("User is not on application home page"); Assert.assertTrue(false);
} else 
{

System.out.println("User is on application home page");
}
}
@Test (priority = 2)
public void click_on_signup_link() {
pobj.signup_link.click();
try {
Thread.sleep(3000);
} catch (InterruptedException e) {
}
System.out.println("Signup link is clicked.");
}

@Test (priority= 3)
public void enter_existed_username_and_valid_password() 
{
pobj.user_input.sendKeys("Rahul123");
pobj.password_input.sendKeys ("abc@12345");
System.out.println("Existing username and valid password is entered");
}

@Test (priority = 4) 
public void click_on_signup_button () {
pobj.signup_button.click();
try {
Thread.sleep(3000);
} catch (InterruptedException e) {
}

System.out.println("Signup button is clicked.");
}

@Test (priority = 5)
public void user_credentials_are_wrong () {
System.out.println("User enters wrong credentials");
}

@Test (priority = 6)
public void user_should_not_be_able_register_into_the_application () {
Alert alert = driver.switchTo().alert();
String signup_message = alert.getText();
if (signup_message.equals("Sign up successful.")) 
{ System.out.println("User is able to register"); System.out.println("test case failed!");
alert.accept();
Assert.assertTrue (false);
} else 
{
System.out.println("User is not able to register");
}
}
@Test (priority = 7)
public void error_message_should_be_displayed_for_existing_username () {
Alert alert = driver.switchTo().alert();
String signup_message = alert.getText();
{
if (signup_message.equals ("This user already exist.")) {
	System.out.println("Error message is displayed for existing username");
} 
else 
{
System.out.println("Error message is not displayed for existing username"); System.out.println("test case failed!");
alert.accept();
Assert.assertTrue(false);
alert.accept();
}
}
}
}