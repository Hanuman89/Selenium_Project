package testrunner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)

@CucumberOptions(
features="src/main/java/feature/",
 glue={"testngClasses"},
 strict = true,
 plugin = {"json: target/reports/report.json", "junit: target/reports/report.xml"}, 
 monochrome = true
 )
public class TestRunner_signup {
public static void main(String[] args) 
{

}
}
