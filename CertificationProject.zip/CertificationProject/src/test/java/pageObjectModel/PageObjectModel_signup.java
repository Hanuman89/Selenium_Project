package pageObjectModel;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.support.FindBy;

public class PageObjectModel_signup {

	public @FindBy(css="#nava") WebElement homepagelogo_img;
	public @FindBy(css="#signin2") WebElement signup_link;
	public @FindBy(css="#signInModal") WebElement signup_window;
	public @FindBy(css="#sign-username") WebElement user_input;
	public @FindBy(css="#sign-password") WebElement password_input;
	public @FindBy(css="#signInModal .btn-primary") WebElement signup_button;
	public @FindBy(css="#signInModal .btn-Secondary") WebElement signupClose_button;

}
